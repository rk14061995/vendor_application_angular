import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-registration',
  templateUrl: './vendor-registration.component.html',
  styleUrls: ['./vendor-registration.component.css']
})
export class VendorRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
