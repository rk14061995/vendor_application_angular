import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-component',
  templateUrl: './other-component.component.html',
  styleUrls: ['./other-component.component.css']
})
export class OtherComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
